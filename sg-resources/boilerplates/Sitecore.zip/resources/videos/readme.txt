Placeholder so that the folder will show up in Source Control correctly.

Video files should be placed within this folder, organized by pages and universal use.