Placeholder so that the folder will show up in Source Control correctly.

Font files should be placed within this folder.