Placeholder so that the folder will show up in Source Control correctly.

JS files should be placed within this folder, organized by component and universal use.