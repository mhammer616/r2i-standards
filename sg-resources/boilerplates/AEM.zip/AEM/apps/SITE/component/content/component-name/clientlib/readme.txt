Placeholder so that the folder will show up in Source Control correctly.

This folder holds the less/js for this specific component. Use consistent naming for the files that match the component name. Also be sure to update the REPLACE text with the project name in the .content.xml file so the component knows to use this css/js.